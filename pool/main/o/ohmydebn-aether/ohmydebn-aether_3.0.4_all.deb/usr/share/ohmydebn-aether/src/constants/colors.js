/**
 * Color-related constants and default values
 */

// ANSI color role definitions with semantic names
export const ANSI_COLOR_ROLES = [
    {
        id: 'background',
        label: 'Background',
        description: 'Primary background color',
    },
    {id: 'foreground', label: 'Foreground', description: 'Primary text color'},
    {id: 'black', label: 'Black', description: 'Normal black (ANSI 0)'},
    {id: 'red', label: 'Red', description: 'Normal red (ANSI 1)'},
    {id: 'green', label: 'Green', description: 'Normal green (ANSI 2)'},
    {id: 'yellow', label: 'Yellow', description: 'Normal yellow (ANSI 3)'},
    {id: 'blue', label: 'Blue', description: 'Normal blue (ANSI 4)'},
    {id: 'magenta', label: 'Magenta', description: 'Normal magenta (ANSI 5)'},
    {id: 'cyan', label: 'Cyan', description: 'Normal cyan (ANSI 6)'},
    {id: 'white', label: 'White', description: 'Normal white (ANSI 7)'},
    {
        id: 'bright_black',
        label: 'Bright Black',
        description: 'Bright black (ANSI 8)',
    },
    {id: 'bright_red', label: 'Bright Red', description: 'Bright red (ANSI 9)'},
    {
        id: 'bright_green',
        label: 'Bright Green',
        description: 'Bright green (ANSI 10)',
    },
    {
        id: 'bright_yellow',
        label: 'Bright Yellow',
        description: 'Bright yellow (ANSI 11)',
    },
    {
        id: 'bright_blue',
        label: 'Bright Blue',
        description: 'Bright blue (ANSI 12)',
    },
    {
        id: 'bright_magenta',
        label: 'Bright Magenta',
        description: 'Bright magenta (ANSI 13)',
    },
    {
        id: 'bright_cyan',
        label: 'Bright Cyan',
        description: 'Bright cyan (ANSI 14)',
    },
    {
        id: 'bright_white',
        label: 'Bright White',
        description: 'Bright white (ANSI 15)',
    },
    // Extended color roles (editable, auto-derived from palette by default)
    {
        id: 'accent',
        label: 'Accent',
        description: 'Accent color for highlights and interactive elements',
    },
    {
        id: 'cursor',
        label: 'Cursor',
        description: 'Cursor color for text input',
    },
    {
        id: 'selection_foreground',
        label: 'Selection Foreground',
        description: 'Text color when selected',
    },
    {
        id: 'selection_background',
        label: 'Selection Background',
        description: 'Background color when selected',
    },
];

// Map semantic names to color0-15 for backwards compatibility
export const COLOR_NAME_TO_INDEX = {
    black: 'color0',
    red: 'color1',
    green: 'color2',
    yellow: 'color3',
    blue: 'color4',
    magenta: 'color5',
    cyan: 'color6',
    white: 'color7',
    bright_black: 'color8',
    bright_red: 'color9',
    bright_green: 'color10',
    bright_yellow: 'color11',
    bright_blue: 'color12',
    bright_magenta: 'color13',
    bright_cyan: 'color14',
    bright_white: 'color15',
};

// Default color scheme (Tokyo Night)
// Uses semantic names (black, red, etc.) as primary keys
export const DEFAULT_COLORS = {
    background: '#1a1b26',
    foreground: '#a9b1d6',
    black: '#15161e',
    red: '#f7768e',
    green: '#9ece6a',
    yellow: '#e0af68',
    blue: '#7aa2f7',
    magenta: '#bb9af7',
    cyan: '#7dcfff',
    white: '#a9b1d6',
    bright_black: '#414868',
    bright_red: '#f7768e',
    bright_green: '#9ece6a',
    bright_yellow: '#e0af68',
    bright_blue: '#7aa2f7',
    bright_magenta: '#bb9af7',
    bright_cyan: '#7dcfff',
    bright_white: '#c0caf5',
    // Extended colors (derived from palette by default)
    accent: '#7aa2f7', // blue
    cursor: '#a9b1d6', // foreground
    selection_foreground: '#1a1b26', // background (inverted)
    selection_background: '#a9b1d6', // foreground (inverted)
};

// ANSI color names for tooltips with descriptions
export const ANSI_COLOR_NAMES = [
    'Black (0) - Normal black, used for dark text and backgrounds',
    'Red (1) - Normal red, used for errors and warnings',
    'Green (2) - Normal green, used for success messages and confirmations',
    'Yellow (3) - Normal yellow, used for warnings and highlights',
    'Blue (4) - Normal blue, used for information and links',
    'Magenta (5) - Normal magenta, used for special elements and constants',
    'Cyan (6) - Normal cyan, used for strings and secondary information',
    'White (7) - Normal white, used for regular text',
    'Bright Black (8) - Comments and dimmed text',
    'Bright Red (9) - Intense errors and critical warnings',
    'Bright Green (10) - Emphasized success and completions',
    'Bright Yellow (11) - Important warnings and search highlights',
    'Bright Blue (12) - Emphasized information and active links',
    'Bright Magenta (13) - Special keywords and focused elements',
    'Bright Cyan (14) - Highlighted strings and important data',
    'Bright White (15) - Bold text and headings',
];

// Color harmony types
export const HARMONY_TYPES = [
    'Analogous',
    'Monochromatic',
    'Complementary',
    'Split Complementary',
    'Shades',
    'Squares',
];

// Color adjustment limits
export const ADJUSTMENT_LIMITS = {
    vibrance: {min: -50, max: 50, step: 5, default: 0},
    saturation: {min: -100, max: 100, step: 5, default: 0},
    contrast: {min: -30, max: 30, step: 5, default: 0},
    brightness: {min: -30, max: 30, step: 5, default: 0},
    shadows: {min: -50, max: 50, step: 5, default: 0},
    highlights: {min: -50, max: 50, step: 5, default: 0},
    hue: {min: -180, max: 180, step: 10, default: 0},
    temperature: {min: -50, max: 50, step: 5, default: 0},
    tint: {min: -50, max: 50, step: 5, default: 0},
    blackPoint: {min: -30, max: 30, step: 5, default: 0},
    whitePoint: {min: -30, max: 30, step: 5, default: 0},
    gamma: {min: 0.5, max: 2.0, step: 0.1, default: 1.0},
};

// Default palette array (16 ANSI colors in index order)
// Used by ThemeState for initial palette (Catppuccin-inspired)
export const DEFAULT_PALETTE = [
    '#1e1e2e', // 0: Background/Black
    '#f38ba8', // 1: Red
    '#a6e3a1', // 2: Green
    '#f9e2af', // 3: Yellow
    '#89b4fa', // 4: Blue
    '#cba6f7', // 5: Magenta
    '#94e2d5', // 6: Cyan
    '#cdd6f4', // 7: White
    '#45475a', // 8: Bright Black
    '#f38ba8', // 9: Bright Red
    '#a6e3a1', // 10: Bright Green
    '#f9e2af', // 11: Bright Yellow
    '#89b4fa', // 12: Bright Blue
    '#cba6f7', // 13: Bright Magenta
    '#94e2d5', // 14: Bright Cyan
    '#ffffff', // 15: Bright White
];

// Palette configuration
export const PALETTE_CONFIG = {
    totalColors: 16,
    previewColors: 6,
    shadeCount: 15,
    maxChildrenPerLine: 8,
    minChildrenPerLine: 8,
};

// Color swatch dimensions
export const SWATCH_DIMENSIONS = {
    default: {width: 35, height: 35},
    large: {width: 40, height: 40},
};
