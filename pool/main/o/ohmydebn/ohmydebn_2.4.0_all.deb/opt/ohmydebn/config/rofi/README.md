The Rofi themes in this directory came from:

https://github.com/newmanls/rofi-themes-collection
