#!/bin/bash

/opt/ohmydebn/bin/ohmydebn-headline "tte rain" "Installing any available OS updates"
sudo apt -y dist-upgrade
