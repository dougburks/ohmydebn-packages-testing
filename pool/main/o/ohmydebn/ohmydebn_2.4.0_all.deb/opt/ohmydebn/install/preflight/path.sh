#!/bin/bash

export PATH="/opt/ohmydebn/bin:$PATH"
