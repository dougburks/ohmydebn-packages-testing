#!/bin/bash

/opt/ohmydebn/bin/ohmydebn-logo-generate
