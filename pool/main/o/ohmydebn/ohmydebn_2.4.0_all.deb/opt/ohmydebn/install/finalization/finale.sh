#!/bin/bash

if [ -f ~/.local/state/ohmydebn ]; then
  if [ ! -f /etc/apt/sources.list.d/ohmydebn.sources ]; then
    sudo tee /etc/apt/sources.list.d/ohmydebn.sources <<EOF
Types: deb
URIs: https://dougburks.github.io/ohmydebn-packages-testing/
Suites: trixie
Components: main
Signed-By: /usr/share/keyrings/ohmydebn-keyring.gpg
EOF
  fi
  if [ ! -f /usr/share/keyrings/ohmydebn-keyring.gpg ]; then
    curl -fsSL https://dougburks.github.io/ohmydebn-packages-testing/repo-key.asc |
      sudo gpg --dearmor -o /usr/share/keyrings/ohmydebn-keyring.gpg
  fi
  if ! dpkg -s "ohmydebn" >/dev/null 2>&1; then
    sudo apt update
    sudo apt install -y ohmydebn
  fi
  /opt/ohmydebn/bin/ohmydebn-headline "tte rain" "OhMyDebn update complete!"
else
  echo
  /opt/ohmydebn/bin/ohmydebn-headline "tte rain" "Installation complete!"
  echo
  toilet -f mono12 "Welcome" | tte rain
  toilet -f mono12 "   to" | tte rain
  toilet -f mono12 "OhMyDebn" | tte rain
  # Create a state file signifying that installation is complete
  mkdir -p ~/.local/state
  touch ~/.local/state/ohmydebn
fi
