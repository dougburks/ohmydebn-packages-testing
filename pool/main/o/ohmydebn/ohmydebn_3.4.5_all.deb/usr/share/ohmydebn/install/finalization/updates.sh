#!/bin/bash

set -euo pipefail

/usr/share/ohmydebn/bin/ohmydebn-headline "tte rain" "Installing any available package updates"

# Update system packages
/usr/share/ohmydebn/bin/ohmydebn-update-system-pkgs

# Update optional packages that are hosted elsewhere
/usr/share/ohmydebn/bin/ohmydebn-update-optional

# Install automatic update check
/usr/share/ohmydebn/bin/ohmydebn-update-check-install
