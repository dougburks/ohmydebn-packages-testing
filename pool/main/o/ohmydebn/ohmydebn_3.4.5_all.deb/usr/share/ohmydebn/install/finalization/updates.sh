#!/bin/bash

/usr/share/ohmydebn/bin/ohmydebn-headline "tte rain" "Installing any available package updates"
sudo apt update && sudo DEBIAN_FRONTEND=noninteractive apt -y full-upgrade

if dpkg -s "open-code" >/dev/null 2>&1; then
  echo
  /usr/share/ohmydebn/bin/ohmydebn-opencode-install
fi

if dpkg -s "localsend" >/dev/null 2>&1; then
  echo
  /usr/share/ohmydebn/bin/ohmydebn-localsend-install
fi
