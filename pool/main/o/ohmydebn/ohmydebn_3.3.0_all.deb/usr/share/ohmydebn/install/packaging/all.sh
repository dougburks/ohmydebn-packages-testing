#!/bin/bash

source $OHMYDEBN_INSTALL/packaging/cinnamon.sh
source $OHMYDEBN_INSTALL/packaging/dbus.sh
source $OHMYDEBN_INSTALL/packaging/opencode.sh
source $OHMYDEBN_INSTALL/packaging/remove.sh
