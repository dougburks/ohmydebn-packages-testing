#!/bin/bash

/usr/share/ohmydebn/bin/ohmydebn-headline "cat" "Checking to see if opencode needs to be installed or updated"
/usr/share/ohmydebn/bin/ohmydebn-pkg-check-opencode
