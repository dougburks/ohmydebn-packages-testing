# Place in ~/.claude/skills since all tools populate from there as well as their own sources
mkdir -p ~/.claude/skills
ln -s /usr/share/ohmydebn/config/ohmydebn-skill ~/.claude/skills/ohmydebn
